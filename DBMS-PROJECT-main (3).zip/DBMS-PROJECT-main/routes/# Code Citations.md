# Code Citations

## License: unknown
https://github.com/pathanmy2/NewOnlineStore/tree/7444c5db507da68f72768d3cd91150c4c39cc9e2/templates/view_cart.html

```
product.name }}</h3>
    <p>{{ product.description }}</p>
    <p>Price: ${{ product.price }}</p>
    <p>Stock: {{ product.stock }}</p
```

